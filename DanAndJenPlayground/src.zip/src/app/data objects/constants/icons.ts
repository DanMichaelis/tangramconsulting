export class Icons {
    public static readonly pencil: string = 'fa fa-pencil';
    public static readonly trashcan: string = 'fa fa-trash';
    public static readonly add: string = 'fa fa-plus';
    public static readonly edit: string = 'fa fa-pencil-square-o';
}