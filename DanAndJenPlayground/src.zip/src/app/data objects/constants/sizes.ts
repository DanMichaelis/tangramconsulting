export class Sizes {
    public static readonly small: number = 25;
    public static readonly medium: number = 35;
    public static readonly large: number = 50;
}