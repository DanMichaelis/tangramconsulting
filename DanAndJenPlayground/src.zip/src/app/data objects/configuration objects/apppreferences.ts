export class AppPreferences {
    
}